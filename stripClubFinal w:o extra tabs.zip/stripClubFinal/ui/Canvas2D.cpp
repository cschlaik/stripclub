/**
 * @file Canvas2D.cpp
 *
 * CS123 2-dimensional canvas. Contains support code necessary for Brush, Filter, Intersect, and
 * Ray.
 *
 * YOU WILL NEED TO FILL THIS IN!
 *
 */

// For your convenience, a few headers are included for you.
#include <assert.h>
#include <iostream>
#include <math.h>
#include <memory>
#include <unistd.h>
#include "Canvas2D.h"
#include "Settings.h"

//im adding
#include <ui_mainwindow.h>

#include <QPainter>

#include "Camera.h"
#include <glm.hpp>


Canvas2D::Canvas2D()
    // @TODO: Initialize any pointers in this class here.
    //m_rayScene(nullptr),
  //m_brush(nullptr)
 // m_currentShape(nullptr)



{
}

Canvas2D::~Canvas2D()
{
}

// This is called when the canvas size is changed. You can change the canvas size by calling
// resize(...). You probably won't need to fill this in, but you can if you want to.
void Canvas2D::notifySizeChanged(int w, int h) {
}

void Canvas2D::paintEvent(QPaintEvent *e) {
    // You probably won't need to fill this in, but you can if you want to override any painting
    // events for the 2D canvas. For now, we simply call the superclass.
    SupportCanvas2D::paintEvent(e);

}

//// ********************************************************************************************
//// ** BRUSH
//// ********************************************************************************************


void Canvas2D::mouseDown(int x, int y) {
//    // @TODO: [BRUSH] Mouse interaction for brush. You will probably want to create a separate
//    //        class for each of your brushes. Remember that you can use the static Settings
//    //        object to get the currently selected brush and its parameters.

//    // You're going to need to leave the alpha value on the canvas itself at 255, but you will
//    // need to use the actual alpha value to compute the new color of the pixel

////    bool fixAlphaBlending = settings.fixAlphaBlending; // for extra/half credit

//    //    std::cout<< "mouse x is"<<std::endl;
////    std::cout<< x <<std::endl;
////    std::cout<< "mouse y is"<<std::endl;
////    std::cout<< y <<std::endl;
//   // std::cout<< m_marqueeStart<<std::endl;

// //   if(settings.brushType == 1){

//  //  }
//    //Brush::brushDragged(x, y, this);
//    //std::cout<< settings.brushType <<std::endl;

}

void Canvas2D::mouseDragged(int x, int y) {
//    // TODO: [BRUSH] Mouse interaction for Brush.

//    //call brushDragged on my pointer to brush, passing it the canvas (this)
//    m_brush->brushDragged(x, y, this);


}

void Canvas2D::mouseUp(int x, int y) {
//    // TODO: [BRUSH] Mouse interaction for Brush.


}
void Canvas2D::settingsChanged() {

}
