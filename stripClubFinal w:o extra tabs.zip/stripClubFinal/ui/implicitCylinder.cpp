#include "implicitCylinder.h"

implicitCylinder::implicitCylinder()
{

}
