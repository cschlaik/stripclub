# stripclub
cs123 final
