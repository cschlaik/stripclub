hi

i didn't make any super unusual design desicions, pretty much everything is just according to the handout
didn't manage to implement flyweight pattern

known errors are really just leftover shape tessellation problems
sphere is incorrect, so all spheres look dodgy
similarly, if you put p1 all the way down it does weird things to my cone and cylinder bases

