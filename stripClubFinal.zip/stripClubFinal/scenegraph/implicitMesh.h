#ifndef IMPLICITMESH_H
#define IMPLICITMESH_H


class implicitMesh
{
public:
    implicitMesh();
};

#endif // IMPLICITMESH_H