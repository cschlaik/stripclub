#ifndef RAYTEMP_H
#define RAYTEMP_H


class raytemp
{
public:
    raytemp();
};

#endif // RAYTEMP_H