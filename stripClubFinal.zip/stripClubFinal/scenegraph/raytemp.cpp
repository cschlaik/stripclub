#include "raytemp.h"

raytemp::raytemp()
{

}
