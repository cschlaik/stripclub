#include "implicitMesh.h"

implicitMesh::implicitMesh()
{

}
