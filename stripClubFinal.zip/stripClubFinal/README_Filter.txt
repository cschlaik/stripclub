hello

there is some really bad design here! Although I made the different types of filter inherit from a Filter class, I didn't actually have
time to make use of this inheritance to factor out code, nor have i used composition, oh dear!

i have some functionality though, though it's not the best!

I implemented blur with a Gaussian kernel

Know errors/bugs:

-I havent accounted for edge cases, so blurring incorporates a black border
-Similarly, my marqee selection leaves a border
-my scale is sort of close, but messed up. as it is, it will probably crash if you try it on anything other than sf as 1 for x and y, though not always. The x
direction scaling is very close to working -- it stretches the image in the x direction, and the canvas is resixed correctly. However, for some reason it shrinks
by half in the y direction. I believe this an error from how I am indexing into the original image, but I can't work out where. It also often crashes if sf is not 1 :(
-i have no marquee in scale
-unfortunately, i have no special filter
