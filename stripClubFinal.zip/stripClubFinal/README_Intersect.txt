hello!

bunch of known errors!

also, super slow~! didn't have time to implement any speed optimizations so the more shapes, the
(considerably) slower

-some shape speckling that didn't appear working locally but is surely due to not using epsilons in all my
intersection checks
-for some reason, even though i am checking for and using my smallest t, the cone and cylinder caps seem
to be drawing in front of the body
-program might not be able to handle instances where unimplemented shapes are called on
-cone and cylinder body lighting not working properly. black if you load unit_cone, solid if you load conefixed --
was working locally :( ). renders as black so can't see against background but it IS there
