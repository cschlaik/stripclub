/**
 * @file   CamtransCamera.cpp
 *
 * This is the perspective camera class you will need to fill in for the Camtrans lab.  See the
 * lab handout for more details.
 */

#include "CamtransCamera.h"
#include <Settings.h>
#include <iostream>

CamtransCamera::CamtransCamera()
{
    // @TODO Task 3: [CAMTRANS] Set up the default camera settings to match the demo...
    setClip(1.0, 30.0);
    setHeightAngle(60.0);
    setAspectRatio(1.0);
    orientLook(glm::vec4{2, 2, 2, 0}, glm::vec4{0, 0, 0, 1}, glm::vec4{0, 1, 0, 0});
}

glm::mat4x4 CamtransCamera::getProjectionMatrix() const {
    // TODO Task 3: Camtrans
    //CHECK THIS
    return m_perspectiveTransformation*m_scaleMatrix;
}

glm::mat4x4 CamtransCamera::getViewMatrix() const {
    // TODO Task 3: Camtrans
    return m_rotationMatrix*m_translationMatrix;
}

glm::mat4x4 CamtransCamera::getScaleMatrix() const {
    // TODO Task 1: Camtrans
    return m_scaleMatrix;
}

glm::mat4x4 CamtransCamera::getPerspectiveMatrix() const {
    // TODO Task 1: Camtrans
    return m_perspectiveTransformation;
}

glm::vec4 CamtransCamera::getPosition() const {
    // TODO Task 1: Camtrans
    return m_eye;
}

glm::vec4 CamtransCamera::getU() const {
    // TODO Task 1: Camtrans
    return m_u;
}

glm::vec4 CamtransCamera::getV() const {
    // TODO Task 1: Camtrans
    return m_v;
}

glm::vec4 CamtransCamera::getW() const {
    // TODO Task 1: Camtrans
    return m_w;
}

// This function is named poorly. It is not asking for the original
// look vector. Rather, the new look vector computed using w.
glm::vec4 CamtransCamera::getLook() const {
    // TODO Task 1: Camtrans
    //unsure
    return -m_w;
}

float CamtransCamera::getAspectRatio() const {
    // TODO Task 1: Camtrans
    return m_aspectRatio;
}

float CamtransCamera::getHeightAngle() const {
    // TODO Task 1: Camtrans
    return glm::radians(m_thetaH);
}

void CamtransCamera::orientLook(const glm::vec4 &eye, const glm::vec4 &look, const glm::vec4 &up) {
  // TODO Task 3: Camtrans
            m_eye = eye;
            //m_look = &look;
            m_up = up;


            m_w = -glm::normalize(look);
            m_v = glm::normalize(m_up - glm::dot(m_up, m_w)*m_w);
            m_u = glm::vec4{glm::cross(glm::vec3{m_v[0], m_v[1], m_v[2]}, glm::vec3{m_w[0], m_w[1], m_w[2]}), 0};
            updateViewMatrix();
            updateProjectionMatrix();
}

void CamtransCamera::setHeightAngle(float h) {
    // TODO Task 3: Camtrans
    m_thetaH = glm::radians(h);
    float w = m_aspectRatio*(2*m_far*tan(m_thetaH/2));
    m_thetaW = 2 * atan((w/2)/m_far);
    updateProjectionMatrix();

}

void CamtransCamera::setAspectRatio(float a) {
    // TODO Task 3: Camtrans
            m_aspectRatio = a;
            updateProjectionMatrix();
}

void CamtransCamera::translate(const glm::vec4 &v) {
    // TODO: Camtrans
    m_eye = m_eye + v;
    updateViewMatrix();
}

void CamtransCamera::rotateU(float degrees) {
    // TODO Task 3: Camtrans
    //pitch
    glm::vec4 w0 = m_w;
    glm::vec4 v0 = m_v;
    m_v = (m_w*glm::sin(glm::radians(degrees))) + (m_v*glm::cos(glm::radians(degrees)));
    m_w = w0*glm::cos(glm::radians(degrees)) - v0*glm::sin(glm::radians(degrees));
    updateViewMatrix();

}

void CamtransCamera::rotateV(float degrees) {
    // TODO Task 3: Camtrans
    //yaw
    glm::vec4 w0 = m_w;
    glm::vec4 u0 = m_u;
    m_u = u0*glm::cos(glm::radians(degrees)) - w0*glm::sin(glm::radians(degrees));
    m_w = u0*glm::sin(glm::radians(degrees)) + w0*glm::cos(glm::radians(degrees));
    updateViewMatrix();

}

void CamtransCamera::rotateW(float degrees) {
    // TODO Task 3: Camtrans
    //roll
    glm::vec4 u0 = m_u;
    glm::vec4 v0 = m_v;
    m_u = m_u * glm::cos(glm::radians(-degrees)) - m_v*glm::sin(glm::radians(-degrees));
    m_v = u0*glm::sin(glm::radians(-degrees)) + v0*glm::cos(glm::radians(-degrees));
    updateViewMatrix();

}

void CamtransCamera::setClip(float nearPlane, float farPlane) {
    // TODO Task 3: Camtrans

    m_near = nearPlane;
    m_far = farPlane;
    updateProjectionMatrix();
}

// @TODO Task 1: Define the helper methods for updating the matrices here...
void CamtransCamera::updateProjectionMatrix(){
    updateScaleMatrix();
    updatePerspectiveMatrix();

}

void CamtransCamera::updatePerspectiveMatrix(){
    //is this right?
    m_perspectiveTransformation = glm::mat4(1, 0, 0, 0,
                                    0, 1, 0, 0,
                                    0, 0, -1/(-m_near/m_far + 1), (-m_near/m_far)/(-m_near/m_far + 1),
                                    0, 0, -1, 0);
    m_perspectiveTransformation = glm::transpose(m_perspectiveTransformation);

}

void CamtransCamera::updateScaleMatrix(){
    m_scaleMatrix = glm::mat4(1/(m_aspectRatio*(m_far*tan(m_thetaH/2))), 0, 0, 0,
                              0, 1/(m_far*tan(m_thetaH/2)), 0, 0,
                              0, 0, 1/m_far, 0,
                              0, 0, 0, 1);
    m_scaleMatrix = glm::transpose(m_scaleMatrix);

}

void CamtransCamera::updateViewMatrix(){
    //is this in algo?
    updateTranslationMatrix();
    updateRotationMatrix();

}

void CamtransCamera::updateRotationMatrix(){
    m_rotationMatrix = glm::mat4(m_u[0], m_u[1], m_u[2], 0,
                                 m_v[0], m_v[1], m_v[2], 0,
                                 m_w[0], m_w[1], m_w[2], 0,
                                 0, 0, 0, 1);
    m_rotationMatrix = glm::transpose(m_rotationMatrix);

}

void CamtransCamera::updateTranslationMatrix(){
    m_translationMatrix = glm::mat4(1, 0, 0, -m_eye[0],
                           0, 1, 0, -m_eye[1],
                           0, 0, 1, -m_eye[2],
                           0, 0, 0, 1);
    m_translationMatrix = glm::transpose(m_translationMatrix);
}

// @TODO Task 2: Fill in the helper methods you created for updating the matrices...
