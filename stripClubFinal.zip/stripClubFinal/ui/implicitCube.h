#ifndef IMPLICITCUBE_H
#define IMPLICITCUBE_H


class implicitCube
{
public:
    implicitCube();
};

#endif // IMPLICITCUBE_H