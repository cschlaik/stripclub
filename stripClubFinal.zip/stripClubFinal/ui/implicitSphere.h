#ifndef IMPLICITSPHERE_H
#define IMPLICITSPHERE_H


class implicitSphere
{
public:
    implicitSphere();
};

#endif // IMPLICITSPHERE_H