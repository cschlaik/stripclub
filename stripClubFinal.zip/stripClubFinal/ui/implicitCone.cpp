#include "implicitCone.h"

implicitCone::implicitCone()
{

}
