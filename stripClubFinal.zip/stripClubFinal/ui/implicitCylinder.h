#ifndef IMPLICITCYLINDER_H
#define IMPLICITCYLINDER_H


class implicitCylinder
{
public:
    implicitCylinder();
};

#endif // IMPLICITCYLINDER_H