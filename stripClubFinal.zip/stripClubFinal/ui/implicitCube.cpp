#include "implicitCube.h"

implicitCube::implicitCube()
{

}
