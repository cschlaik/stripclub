/**
 * @file Canvas2D.cpp
 *
 * CS123 2-dimensional canvas. Contains support code necessary for Brush, Filter, Intersect, and
 * Ray.
 *
 * YOU WILL NEED TO FILL THIS IN!
 *
 */

// For your convenience, a few headers are included for you.
#include <assert.h>
#include <iostream>
#include <math.h>
#include <memory>
#include <unistd.h>
#include "Canvas2D.h"
#include "Settings.h"

//im adding
#include <ui_mainwindow.h>

#include <QPainter>

#include "Camera.h"
#include <glm.hpp>


Canvas2D::Canvas2D()
    // @TODO: Initialize any pointers in this class here.
    //m_rayScene(nullptr),
  //m_brush(nullptr)
 // m_currentShape(nullptr)



{
}

Canvas2D::~Canvas2D()
{
}

// This is called when the canvas size is changed. You can change the canvas size by calling
// resize(...). You probably won't need to fill this in, but you can if you want to.
void Canvas2D::notifySizeChanged(int w, int h) {
}

void Canvas2D::paintEvent(QPaintEvent *e) {
    // You probably won't need to fill this in, but you can if you want to override any painting
    // events for the 2D canvas. For now, we simply call the superclass.
    SupportCanvas2D::paintEvent(e);

}

//// ********************************************************************************************
//// ** BRUSH
//// ********************************************************************************************


void Canvas2D::mouseDown(int x, int y) {
//    // @TODO: [BRUSH] Mouse interaction for brush. You will probably want to create a separate
//    //        class for each of your brushes. Remember that you can use the static Settings
//    //        object to get the currently selected brush and its parameters.

//    // You're going to need to leave the alpha value on the canvas itself at 255, but you will
//    // need to use the actual alpha value to compute the new color of the pixel

////    bool fixAlphaBlending = settings.fixAlphaBlending; // for extra/half credit

//    //    std::cout<< "mouse x is"<<std::endl;
////    std::cout<< x <<std::endl;
////    std::cout<< "mouse y is"<<std::endl;
////    std::cout<< y <<std::endl;
//   // std::cout<< m_marqueeStart<<std::endl;

// //   if(settings.brushType == 1){

//  //  }
//    //Brush::brushDragged(x, y, this);
//    //std::cout<< settings.brushType <<std::endl;

}

void Canvas2D::mouseDragged(int x, int y) {
//    // TODO: [BRUSH] Mouse interaction for Brush.

//    //call brushDragged on my pointer to brush, passing it the canvas (this)
//    m_brush->brushDragged(x, y, this);


}

void Canvas2D::mouseUp(int x, int y) {
//    // TODO: [BRUSH] Mouse interaction for Brush.


}



// ********************************************************************************************
// ** FILTER
// ********************************************************************************************

void Canvas2D::filterImage() {


//     std::unique_ptr<Filter> myFilter;

//     //depending on the filter type, i initialize myFilter
//    switch(settings.filterType) {
//        case FILTER_EDGE_DETECT:
//        myFilter = std::make_unique<EdgeDetect>();
//            break;
//        case FILTER_BLUR:
//            myFilter = std::make_unique<Blur>();
//            break;
//    case FILTER_SCALE:
//            myFilter = std::make_unique<Scale>();
//            break;
//    }

//    myFilter->apply(this);

//    this->update();
}

////convert pixel coordinates (x,y) to Pfilm -- point on the normalized film plane, (px,py,pz)
//glm::vec3 Canvas2D::pixToFilm(int x, int y){
//    return glm::vec3((2*x)/this->width() - 1, 1 - (2*y)/this->height(), -1);
//}

////transform Pfilm from normalized film plane into untransformed world space point Pworld
//glm::vec4 Canvas2D::filmToWorld(glm::vec3 Pfilm, Camera *camera){
//    //CHECK ORDER
//   glm::mat4 filmToWorld = glm::inverse(camera->getViewMatrix())*
//           glm::inverse(camera->getScaleMatrix());

//   return filmToWorld*glm::vec4(Pfilm, 1.0);
//}


void Canvas2D::cancelRender() {
    // TODO: cancel the raytracer (optional)
}



void Canvas2D::settingsChanged() {
//    // TODO: Process changes to the application settings.

//    //if the brush type is constant, update the brush pointer to point to constant brush
//    if(settings.brushType == BRUSH_CONSTANT){
//        m_brush = std::make_unique<ConstantBrush>(settings.brushColor, settings.brushRadius);
//    }
//    //then presumably do the same in the case of it being another brush
//    else if(settings.brushType == BRUSH_LINEAR){
//        m_brush = std::make_unique<LinearBrush>(settings.brushColor, settings.brushRadius);
//    }

//    else if(settings.brushType == BRUSH_QUADRATIC){
//        m_brush = std::make_unique<QuadraticBrush>(settings.brushColor, settings.brushRadius);
//    }

//    else if(settings.brushType == BRUSH_SMUDGE){
//        m_brush = std::make_unique<SmudgeBrush>(settings.brushColor, settings.brushRadius);
//    }




}
