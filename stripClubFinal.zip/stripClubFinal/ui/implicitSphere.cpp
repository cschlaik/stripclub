#include "implicitSphere.h"

implicitSphere::implicitSphere()
{

}
