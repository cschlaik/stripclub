#ifndef IMPLICITCONE_H
#define IMPLICITCONE_H


class implicitCone
{
public:
    implicitCone();
};

#endif // IMPLICITCONE_H