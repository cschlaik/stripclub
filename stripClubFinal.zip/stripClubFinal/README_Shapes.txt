hello

I have a parent shape class, which my cube, sphere, cylinder, cone, etc. classes inherit from so as to avoid repeating
code. Shape inherits from OpenGLShape, so that it can use its methods like draw, setVertexData etc. It took me so long
to figure out the correct way to do this (I didn't realise that Shape had to inherit from OpenGlShape, which was causing
problems) that I didn't have time to implement all of my shapes properly. Cube and cylinder and cone are the nicest. Look at those first!
Look at sphere last. It's not the prettiest sight!

In settingsChanged(), I check to see what shape is selected and then initialize a currentShape of the relevant type.
In the constructor of each of my children classes, the method to make the vector specifying the shape vertices is
called, so that the shape is built on initializing it as the currentShape variable. Each child class of Shape builds
the vector of vertices in the way specific to its shape. Then it calls Shape's setUpShape method, passing in the vector,
and Shape calls setVertexData etc. which are common steps for all shapes.

Known Errors or Problems:
-my cylinder is fully functional apart from when param1 is 1. then the inner central fan doubles in size. I account
for the lower cap (i.e. if param2 goes below 3, the cylinder still keeps 3 sides so you don't get an unregocnisable
shape. However,  I think there an error perhaps from the radius being overmultiplied that causes this bug

-this also causes a similar error in cone, where the base doubles in size when param1 is 1.

-my cube has a lot of hard coding. I could make it more elegant/efficient/extensibles by having variables for the vertices coordinates
pretty much everywhere I have a hard coded number

-if i had more time, I would use composition to factor out methods common to subclasses, like for making cylinder and cone's bases

-my sphere is really unspherical and messy and not great! i had trouble extrapolating from the demo how param1 affected the segmentation,
and how to implement that, and whether i needed to use spherical coordinates when it seemed like i could just adapt my code from cone
and achieve the right result (clearly not the case at this point)

-normals for cone dont match those of the demo
