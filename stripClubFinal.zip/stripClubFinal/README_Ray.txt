Dear Reader,

Hello and welcome to a wonderfully exciting albeit unfinished Ray.

Please grade THIS ONE if there are multiple project folders in my handin

i refactored my Scene code, to include a vector of QImages to correspond to my vector of primitives at each node
if a primitive has a texture, it is loading during parsing and pushed back onto vector
if not, a null QImage is pushed back
this is to avoid loading a new QImage at every pixel

i've got specular, but in ball test one of the highlights goes black, which is perhaps due to a clamping issue somewhere
i support multiple and directional lights
i have functional texture mapping, but in cube_test.xml the texture is wrapped differently on all 6 cubes, which i am confused by

i have crude shadows

i did not have time to attempt recursive reflection :(

happy thanksgiving
